<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
   <?php
   $host = "localhost";
   $user = "root";
   $password = "";
   $dbname = "lab06sec1";
   $conn = mysqli_connect($host, $user, $password, $dbname);
   if($conn) {
      // echo "Connect database";
      $sql = "SELECT * FROM movies";
      $result = mysqli_query($conn,$sql);


      while($rs = mysqli_fetch_array($result)) {
         $id = $rs["movie_id"];
         $watched = $rs["watched"];
         if($rs["watched"]==1){
            echo "<input type=checkbox checked disabled name=$id value=$watched>";
            echo $rs["movie_title"]."<br>";
            
         }
         else {
            echo "<input type=checkbox name=$id value=$watched>";
            echo $rs["movie_title"]."<br>";
         }
      }
      mysqli_close($conn);
   }
   else {
      echo "Error!";
      exit;
   }
   ?>

</head>
<body>
   <form action="check.php" method="POST">
      <input type="submit" value="Check">
   </form>
</body>
</html>