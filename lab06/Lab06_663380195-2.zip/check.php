<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
   <?php
      if($_SERVER["REQUEST_METHOD"] === "POST") {
         $check = $_POST["$value"];
         echo $check;
      }
      // $host = "localhost";
      // $user = "root";
      // $password = "";
      // $dbname = "lab06sec1";
      // $conn = mysqli_connect($host, $user, $password, $dbname);
      
      // if($conn) {
      //    // echo "Connect database";
      //    if($check==""){
      //       $sql = "UPDATE * SET watched = 1";
      //    }
      // }
   ?>
</head>
<body>
   
</body>
</html>